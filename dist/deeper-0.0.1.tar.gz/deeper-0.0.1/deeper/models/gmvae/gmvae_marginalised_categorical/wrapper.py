import tensorflow as tf 
import numpy as np 

from deeper.models.gmvae.gmvae_marginalised_categorical.model import Gmvae 
from deeper.models.gmvae.gmvae_marginalised_categorical.train import train 


class GMVAE(Gmvae):

    def train(
        self,
        X_train,
        y_train,
        X_test,
        y_test,
        num,
        samples,
        epochs,
        iter_train,
        num_inference,
        batch=False,
        verbose=1,
        save=None,
        beta_z_method=lambda: 1.0,
        beta_y_method=lambda: 1.0,
        tensorboard="./logs",
    ):
       train(
            self, X_train, y_train, X_test, y_test, num, samples, epochs,
            iter_train, num_inference, batch, verbose, save, beta_z_method,
            beta_y_method, tensorboard,
        )
