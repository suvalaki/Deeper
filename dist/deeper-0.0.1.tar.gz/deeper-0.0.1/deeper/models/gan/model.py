import tensorflow as tf 
import nump as np


tfk = tf.keras
Model = tfk.Model


class DescriminatorModel(Model):
    def __init__(self, ):
        pass