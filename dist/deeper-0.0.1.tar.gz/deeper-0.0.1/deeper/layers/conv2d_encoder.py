
import tensorflow as tf 
import numpy as np 
from deeper.utils.scope import Scope

tfk = tf.keras
Layer = tfk.layers.Layer

class Conv2dEncoder(Layer, Scope):
    def __init__(
        self, 
        depth,
        latent_dim, 
        kernel,
        filters:list,
        strides=(3,3),
        padding='SAME',
        activation=tf.nn.relu,
        var_scope='encoder', 
        bn_before=False,
        bn_after=False,
        embedding_kernel_initializer=tf.initializers.glorot_uniform(),
        embedding_bias_initializer=tf.initializers.zeros(),
        latent_kernel_initialiazer=tf.initializers.glorot_uniform(),
        latent_bias_initializer=tf.initializers.zeros(),
        embedding_dropout=0.0
    ):
        Layer.__init__(self)
        Scope.__init__(self, var_scope)

        self.depth = depth
        self.latent_dim = latent_dim
        self.kernel = kernel 
        self.filters = filters 
        self.strides = strides
        self.padding = padding

        # embeddings


        self.embeddings = []
        self.embeddings_bn_before = []
        self.embeddings_bn_after = []
        self.activation = activation
        self.bn_before = bn_before
        self.bn_after = bn_after
        self.dropout_rate = embedding_dropout
        self.dropout = []

        for i,em in enumerate(self.filters):
            self.embeddings.append(
                tfk.layers.Conv2D(
                    em, 
                    kernel,
                    strides,
                    activation=None,
                    use_bias=True,
                    kernel_initializer=embedding_kernel_initializer,
                    bias_initializer=embedding_bias_initializer,
                    name=self.v_name('embedding_{}_dense'.format(i))
                )
            )
            if self.bn_before:
                self.embeddings_bn_before.append(
                    tfk.layers.BatchNormalization(
                        axis=-1, 
                        name=self.v_name('embedding_{}_bn_before'.format(i)),
                        renorm=True
                    )
                )
            else:
                self.embeddings_bn_before.append(None)

            if self.bn_after:
                self.embeddings_bn_after.append(
                    tfk.layers.BatchNormalization(
                        axis=-1,
                        name=self.v_name('embedding_{}_bn_after'.format(i)),
                        renorm=True
                    )
                )
            else:
                self.embeddings_bn_after.append(None)

            if self.dropout_rate > 0.0:
                self.dropout.append(
                    tfk.layers.Dropout(self.dropout_rate)
                )

        self.latent_flat = tfk.layers.Flatten()

        self.latent_bn = tfk.layers.BatchNormalization(
            axis=-1, 
            name=self.v_name('latent_bn')
        )
        self.latent = tfk.layers.Dense(
            units=self.latent_dim,
            activation=None,
            use_bias=True,
            kernel_initializer=latent_kernel_initialiazer,
            bias_initializer=latent_bias_initializer,
            name=self.v_name('latent_dense')
        )

    @tf.function
    def call(self, inputs, training=False):
        """Define the computational flow"""
        x = inputs
        for em, bnb, bna, drp in zip(
            self.embeddings, 
            self.embeddings_bn_before, 
            self.embeddings_bn_after,
            self.dropout
        ):
            x = em(x)
            if self.bn_before:
                x = bnb(x, training=training)
            x = self.activation(x)
            if self.bn_after:
                x = bna(x, training=training)
            if self.dropout_rate > 0.0:
                x = drp(x, training=training)
        x = self.latent(x)
        return x


class Conv2dDecoder(Layer, Scope):
    def __init__(
        self, 
        depth,
        latent_dim, 
        kernel,
        filters:list,
        strides=(3,3),
        padding='SAME',
        activation=tf.nn.relu,
        var_scope='encoder', 
        bn_before=False,
        bn_after=False,
        embedding_kernel_initializer=tf.initializers.glorot_uniform(),
        embedding_bias_initializer=tf.initializers.zeros(),
        latent_kernel_initialiazer=tf.initializers.glorot_uniform(),
        latent_bias_initializer=tf.initializers.zeros(),
        embedding_dropout=0.0
    ):
        Layer.__init__(self)
        Scope.__init__(self, var_scope)

        self.depth = depth
        self.latent_dim = latent_dim
        self.kernel = kernel 
        self.filters = filters 
        self.strides = strides
        self.padding = padding

        # embeddings


        self.embeddings = []
        self.embeddings_bn_before = []
        self.embeddings_bn_after = []
        self.activation = activation
        self.bn_before = bn_before
        self.bn_after = bn_after
        self.dropout_rate = embedding_dropout
        self.dropout = []

        initial_shape = self.strides + (self.kernel[0], )
        self.embedding_dense = tfk.layers.Dense(tf.math.reduce_prod(initial_shape))
        self.embedding_reshape = tfk.layers.Reshape(
            target_shape=initial_shape
        )

        for i,em in enumerate(self.filters):
            self.embeddings.append(
                tfk.layers.Conv2DTranspose(
                    em, 
                    kernel,
                    strides,
                    activation=None,
                    use_bias=True,
                    kernel_initializer=embedding_kernel_initializer,
                    bias_initializer=embedding_bias_initializer,
                    name=self.v_name('embedding_{}_dense'.format(i))
                )
            )
            if self.bn_before:
                self.embeddings_bn_before.append(
                    tfk.layers.BatchNormalization(
                        axis=-1, 
                        name=self.v_name('embedding_{}_bn_before'.format(i)),
                        renorm=True
                    )
                )
            else:
                self.embeddings_bn_before.append(None)

            if self.bn_after:
                self.embeddings_bn_after.append(
                    tfk.layers.BatchNormalization(
                        axis=-1,
                        name=self.v_name('embedding_{}_bn_after'.format(i)),
                        renorm=True
                    )
                )
            else:
                self.embeddings_bn_after.append(None)

            if self.dropout_rate > 0.0:
                self.dropout.append(
                    tfk.layers.Dropout(self.dropout_rate)
                )

        self.latent_bn = tfk.layers.BatchNormalization(
            axis=-1, 
            name=self.v_name('latent_bn')
        )
        self.latent = tfk.layers.Conv2dTranspose(
            filters=1,
            kernel_size=kernel,
            strides=(1,1)
            padding=self.padding
            activation=None,
            use_bias=True,
            kernel_initializer=latent_kernel_initialiazer,
            bias_initializer=latent_bias_initializer,
            name=self.v_name('latent_dense')
        )


    @tf.function
    def call(self, inputs, training=False):
        """Define the computational flow"""
        x = inputs
        for em, bnb, bna, drp in zip(
            self.embeddings, 
            self.embeddings_bn_before, 
            self.embeddings_bn_after,
            self.dropout
        ):
            x = em(x)
            if self.bn_before:
                x = bnb(x, training=training)
            x = self.activation(x)
            if self.bn_after:
                x = bna(x, training=training)
            if self.dropout_rate > 0.0:
                x = drp(x, training=training)
        x = self.latent(x)
        return x

