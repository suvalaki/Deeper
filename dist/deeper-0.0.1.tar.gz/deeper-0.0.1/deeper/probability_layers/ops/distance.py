import tensorflow as tf
import numpy as np


def kl_divergence():
    """Distribution method for kl divergence"""
    pass
