import tensorflow as tf


def rotate(x: tf.Tensor) -> tf.Tensor:
    """Rotation augmentation

    Args:
        x: Image

    Returns:
        Augmented image
    """

    # Rotate 0, 90, 180, 270 degrees
    return tf.image.rot90(
        x, tf.random_uniform(shape=[], minval=0, maxval=4, dtype=tf.int32)
    )
