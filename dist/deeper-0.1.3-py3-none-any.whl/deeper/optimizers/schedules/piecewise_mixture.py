import tensorflow as tf

from typeguard import typechecked

from deeper.utils.cooling import linear_cooling
from typing import Union, Callable
from tensorflow_addons.utils.types import FloatTensorLike


# class to switch between different learning rate schedules such
# that each is shifted
# could allow for interpolation between different regimes




class MixtureLearningRate(tf.keras.optimizers.schedules.LearningRateSchedule):
    @typechecked
    def __init__(
        self,
        regimes: Sequence[tf.keras.optimizers.schedules.LearningRateSchedule],
        steps: Sequence[int],
        interpolate: bool = False,
        name: str = "MixtureLearningRate",
    ):

        ...
        