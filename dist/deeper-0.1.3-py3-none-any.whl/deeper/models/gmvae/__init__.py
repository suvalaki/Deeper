from .model import Gmvae, GumbleGmvae, StackedGmvae
from deeper.models.vae import MultipleObjectiveDimensions
