from __future__ import annotations
import tensorflow as tf
from typing import Sequence

from pydantic import BaseModel, Field
