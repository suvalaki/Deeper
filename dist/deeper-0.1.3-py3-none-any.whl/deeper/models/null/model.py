from .network import Null
