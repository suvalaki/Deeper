import tensorflow as tf
from typing import Optional
