import tensorflow as tf

from tensorflow.python.keras.engine.compile_utils import (
    Container as tfkContainer,
    MetricsContainer as tfkMetricsContainer,
)

# Override the metrics container to allow for dicts?
